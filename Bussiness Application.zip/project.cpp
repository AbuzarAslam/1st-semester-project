//Header Files
#include <iostream>
#include <fstream>
#include <conio.h>
#include <sstream>
using namespace std;
// Function
void mainheader();
void topHeader();
void signUp(string username, string password, string role);
bool isValidUsername(string username);
void storeInfile(string username, string password, string role);
string takeChoice();
void viewUser();
string customerList();
string signIn(string username, string password);
void readDataFromFile();
void readProductsFromFile();
string managerList();
void managerInterface();
void customerInterface();
void addproductsbyManager(string product, float productprice);
void productFile();
void updatePriceFile(int productnumber);
void viewProducts();
void updatePrice(int productnumber, float price);
void deleteFromProductFile(int productnumber);
bool isValidPhoneNumber(string phonenumber);
void chooseProduct();
void seeProducts();
void seeSelectedProducts();
void managerContact(string phonenumber);
string getField(string record, int field);
void viewContact();
void customerAddress(string address);
void deleteCustomerSelectedProducts(int productnumber);
void SelectedProducts();
void viewOrder();
// Global Variables
const int size = 10;
int usercount = 0;
int productcount = 0;
int numbercount=0;
int selectedCount = 0;
string PhoneNumber = "03049149225";
string Address = "No Address";
// Global Arrays
string Username[size];
string Password[size];
string Role[size];
string managerProducts[size];
int Productprice[size];
string selectedproduts[size];
int selectedprice[size];
main()
{
    system("cls");
    mainheader();
    cout << endl<<endl<<"Press any key to continue..";
    getch();
    readDataFromFile();
    string choice;
    system("cls");
    readProductsFromFile();
    while (choice != "3")
    {
        bool decision;
        string username;
        string password;
        string role;
        string category;
        choice = takeChoice();
        if (choice == "1")
        {
            system("cls");
            topHeader();
            cout << "    Sign Up Menu" << endl;
            cout << "..................." << endl;
            cout << "Enter your name....";
            cin >> username;
            cout << "Enter password....";
            cin >> password;
            cout << "Enter your role(Manager/Customer)....";
            cin >> role;
            decision = isValidUsername(username);
            if (decision == true)
            {
                if(usercount>size)
                {
                    cout << "No Space Is Available!"<<endl;
                    cout << "Press any key to continue";
                    getch();
                }
                else
                {
                    signUp(username, password, role);
                    storeInfile(username, password, role);
                    cout << "Signed up successfully!" << endl;
                    cout << "Press any key to continue..." << endl;
                    getch();
                }
            }
            else
            {
                cout << "Same user exist!" << endl;
                cout << "Press any key to continue..." << endl;
                getch();
            }
        }
        else if (choice == "2")
        {
            system("cls");
            topHeader();
            cout << "    Sign In Menu" << endl;
            cout << "..................." << endl;
            if(usercount==0)
            {
                cout << "No user Available!" << endl;
                cout << "Press any key to continue.."<<endl;
                getch();
            }
            else 
            {
                cout << "Enter username....";
                cin >> username;
                cout << "Enter password....";
                cin >> password;
                signIn(username, password);
                category = signIn(username, password);
                if (category == "Manager" || category == "manager")
                {
                    managerInterface();
                }
                else if (category == "Customer" || category == "customer")
                {
                    customerInterface();
                }
                else
                {
                cout <<  "Wrong Password!"<<endl;
                cout << "Press any key to continue";
                getch();
                }
            }
        }
        else if(choice=="3")
        {
            break;
        }
        else if(choice!="1"||choice!="2")
        {
            cout << "Invalid Option"<<endl;
            cout << "Press any key to continue..";
            getch();
        }
    }
}
//main header that will appear once at the start of program
void mainheader()
{
    cout << " 8 8888        8          .8.          8 888888888o.   8 888888888o.      `8.`888b                 ,8'    .8.          8 888888888o.   8 888888888888  "<<endl;
    cout << " 8 8888        8         .888.         8 8888    `88.  8 8888    `^888.    `8.`888b               ,8'    .888.         8 8888    `88.  8 8888          "<<endl;
    cout << " 8 8888        8        :88888.        8 8888     `88  8 8888        `88.   `8.`888b             ,8'    :88888.        8 8888     `88  8 8888          "<<endl;
    cout << " 8 8888        8       . `88888.       8 8888     ,88  8 8888         `88    `8.`888b     .b    ,8'    . `88888.       8 8888     ,88  8 8888          "<<endl;
    cout << " 8 8888        8      .8. `88888.      8 8888.   ,88'  8 8888          88     `8.`888b    88b  ,8'    .8. `88888.      8 8888.   ,88'  8 888888888888  "<<endl;
    cout << " 8 8888        8     .8`8. `88888.     8 888888888P'   8 8888          88      `8.`888b .`888b,8'    .8`8. `88888.     8 888888888P'   8 8888          "<<endl;
    cout << " 8 8888888888888    .8' `8. `88888.    8 8888`8b       8 8888         ,88       `8.`888b8.`8888'    .8' `8. `88888.    8 8888`8b       8 8888          "<<endl;
    cout << " 8 8888        8   .8'   `8. `88888.   8 8888 `8b.     8 8888        ,88'        `8.`888`8.`88'    .8'   `8. `88888.   8 8888 `8b.     8 8888          "<<endl;
    cout << " 8 8888        8  .888888888. `88888.  8 8888   `8b.   8 8888    ,o88P'           `8.`8' `8,`'    .888888888. `88888.  8 8888   `8b.   8 8888          "<<endl;
    cout << " 8 8888        8 .8'       `8. `88888. 8 8888     `88. 8 888888888P'               `8.`   `8'    .8'       `8. `88888. 8 8888     `88. 8 888888888888  "<<endl;
    cout << endl<<endl;
    cout<<"                              d888888o.   8888888 8888888888     ,o888888o.     8 888888888o.   8 888888888888                 "<< endl;
    cout<<"                            .`8888:' `88.       8 8888        . 8888     `88.   8 8888    `88.  8 8888                         "<<endl;
    cout<<"                            8.`8888.   Y8       8 8888       ,8 8888       `8b  8 8888     `88  8 8888                         "<<endl;
    cout<<"                            `8.`8888.           8 8888       88 8888        `8b 8 8888     ,88  8 8888                         "<<endl;
    cout<<"                             `8.`8888.          8 8888       88 8888         88 8 8888.   ,88'  8 888888888888                 "<<endl;
    cout<<"                              `8.`8888.         8 8888       88 8888         88 8 888888888P'   8 8888                         "<<endl;
    cout<<"                               `8.`8888.        8 8888       88 8888        ,8P 8 8888`8b       8 8888                         "<<endl;
    cout<<"                           8b   `8.`8888.       8 8888       `8 8888       ,8P  8 8888 `8b.     8 8888                         "<<endl;
    cout<<"                           `8b.  ;8.`8888       8 8888        ` 8888     ,88'   8 8888   `8b.   8 8888                         "<<endl;
    cout<<"                            `Y8888P ,88P'       8 8888           `8888888P'     8 8888     `88. 8 888888888888                 "<<endl;
    
}
// Header that displays on top of each function
void topHeader()
{
    cout << "************************************************************" << endl;
    cout << "*           Hardware Store Management System               *" << endl;
    cout << "************************************************************" << endl
         << endl;
}
// Function to add users
void signUp(string username, string password, string role)
{
    Username[usercount] = username;
    Password[usercount] = password;
    Role[usercount] = role;
    usercount++;
}
//to check if same user exists
bool isValidUsername(string username)
{
    bool flag = true;
    for (int n = 0; n < usercount; n++)
    {
        if (username == Username[n])
        {
            flag = false;
            break;
        }
    }
    return flag;
}
//store users in file
void storeInfile(string username, string password, string role)
{
    fstream file;
    file.open("UsersFile.txt", ios::app);
    file << username << endl;
    file << password << endl;
    file << role << endl;     
    file.close();
}
//starting Login menu
string takeChoice()
{
    system("cls");
    topHeader();
    string choice;
    cout << "    Login Menu" << endl;
    cout << "..................." << endl;
    cout << "1.Sign up " << endl;
    cout << "2.Sign In " << endl;
    cout << "3.Exit " << endl;
    cout << "Enter choice...";
    cin >> choice;
    return choice;
}
//view all the users(Customers or managers)
void viewUser()
{
    system("cls");
    topHeader();
    cout << "      Users" << endl;
    cout << "..................." << endl;
    for (int n = 0; n < usercount; n++)
    {
        cout << n + 1 << "." << endl << "Username: " << Username[n] << endl << "Password: "<< Password[n] << endl << "Role: "<< Role[n] << endl;
    }
    cout << "Press any key to continue" << endl;
    getch();
}
string signIn(string username, string password)
{
    for (int n = 0; n < usercount; n++)
    {
        if (username == Username[n] && password == Password[n])
        {
            return Role[n];
        }
    }
}
//Read users from file
void readDataFromFile()
{
    string username;
    string password;
    string role;
    fstream file;
    file.open("UsersFile.txt", ios::in);
    while (!file.eof())
    {
        getline(file, username);
        if (username == "")
        {
            break;
        }
        else
        {
            getline(file, password);
            getline(file, role);
            Username[usercount] = username;
            Password[usercount] = password;
            Role[usercount] = role;
            usercount++;
        }
    }
    file.close();
}
string managerList()//List showed to manager
{
    string choice;
    system("cls");
    topHeader();
    cout << "    Manager List." << endl;
    cout << "...................." << endl;
    cout << "1.View the list of products." << endl;
    cout << "2.Add products." << endl;
    cout << "3.Add phone number." << endl;
    cout << "4.Delete products." << endl;
    cout << "5.View Users" << endl;
    cout << "6.Update price of products." << endl;
    cout << "7.View order"<<endl;
    cout << "8.Back" << endl;
    cout << endl << "Choose option...." << endl;
    cin >> choice;
    return choice;
}
void managerInterface()
{
    string option;
    while (option != "8")
    {
        option = managerList();
        if (option == "1")
        {
            system("cls");
            topHeader();
            cout << "    List of products." << endl;
            cout << "........................" << endl;
            if(productcount==0)
            {
                cout << "No Products Available! \n Please add some products!" << endl;
                cout << "Press any key to continue" << endl;
                getch();
            }
            else
            {
                viewProducts();
                cout << "Press any key to contine";
                getch();
            }
        }
        else if (option == "2")
        {
            system("cls");
            topHeader();
            cout << "    Add Product." << endl;
            cout << "...................." << endl;
            string product;
            float productprice;
            cout << "Enter product name..";
            cin.ignore();
            getline(cin, product);
            cout << "Enter price ...";
            cin >> productprice;
            if(productcount>size)
            {
                cout << "No Space Is Available"<<endl;
                cout << "Press any key to continue";
                getch();
            }
            else
            {
                addproductsbyManager(product, productprice);
                productFile();
                cout << "Product added successfully!"<<endl;
                cout << "Press any key to continue";
                getch();
            }
        }
        else if (option == "3")
        {
            system("cls");
            topHeader();
            cout << "      Add Phone Number." << endl;
            cout << "................................." << endl;
            bool result;
            string phonenumber;
            cout << "Enter phone number...";
            cin >> phonenumber;
            result = isValidPhoneNumber(phonenumber);
            if (result == false)
            {
                cout << "invalid Phone Number";
                getch();
            }
            else if (result == true)
            {
                managerContact(phonenumber);
                cout << "Phone Number added successfully!"<<endl;
                cout << "Press any key to continue..";
                getch();
            }
        }
        else if (option == "4")
        {
            system("cls");
            topHeader();
            cout << "       Delete Product." << endl;
            cout << "............................" << endl;
            int productnumber;
            seeProducts();
            cout << "Enter Product do yo want to delete...";
            cin >> productnumber;
            if(productnumber>productcount)
            {
                cout << "Invalid Input"<<endl;
                cout << "Press any key to continue" << endl;
                getch();
            }
            else
            {
                deleteFromProductFile(productnumber);
                productFile();
                cout << "Product deleted successfully!"<<endl;
                cout << "Press any key to continue" << endl;
                getch();
            }
        }
        else if (option == "5")
        {
            system("cls");
            viewUser();
        }
        else if (option == "6")
        {
            system("cls");
            topHeader();
            cout << "   Update price of products." << endl;
            cout << "................................." << endl;
            seeProducts();
            int productnumber;
            float price;
            cout << "Enter product number..";
            cin >> productnumber;
            if(productnumber>productcount||productnumber<1)
            {
                cout << "Invalid Input"<<endl;
                cout << "Press any key to continue" << endl;
                getch();
            }
            else
            {
                cout << "Enter price....";
                cin >> price;
                updatePrice(productnumber, price);
                productFile();
                cout << "Product price updated successfully!"<<endl;
                cout << "Press any key to continue" << endl;
                getch();
            }
        }
        else if (option == "7")
        {
            system("cls");
            topHeader();
            cout << "     Order Available"<<endl;
            cout <<"........................."<<endl;
            if(selectedCount==0)
            {
                cout << "No order is available!" << endl;
                cout << "Press any key to continue" << endl;
                getch();
            }
            else
            {
                viewOrder();
            }
        }
        else if(option=="8")
        {
            break;
        }
        else if(option!="1"||option!="2"||option!="3"||option!="4"||option!="5"||option!="6"||option!="7")
        {
            cout << "Invalid Input"<<endl;
            cout << "Press any key to continue" << endl;
            getch();
        }
    }
}
void customerInterface()
{
    string option;

    while (option != "7")
    {
        option = customerList();
        if (option == "1")
        {
            system("cls");
            topHeader();
            cout << "    List of products." << endl;
            cout << "........................" << endl;
            if(productcount==0)
            {
                cout << "No Products Are Available!"<<endl;
                cout << "Press any key to contine";
                getch();
            }
            else
            {
                viewProducts();
                cout << "Press any key to contine";
                getch();
            }
        }
        else if (option == "2")
        {
            system("cls");
            topHeader();
            cout << "    Choose products." << endl;
            cout << "........................" << endl;
            if(productcount==0)
            {
                cout << "No Products Are Available!"<<endl;
                cout << "Press any key to contine";
                getch();
            }
            else
            {
                chooseProduct();
            }
        }
        else if(option=="3")
        {
            system("cls");
            topHeader();
            cout << "       Customer Address." << endl;
            cout << "................................." << endl;
            string address;
            cin.ignore();
            cout << "Enter your address..";
            getline(cin,address);
            customerAddress(address);
            cout << "Address has added successfully!"<<endl;
            cout << "Press any key to continue";
            getch();
        }
        else if(option=="4")
        {
            system("cls");
            topHeader();
            cout << "       Delete Selcted Product." << endl;
            cout << "....................................." << endl;
            if(selectedCount==0)
            {
                cout <<"No products has been choosen!"<<endl;
                cout << "Press any key to continue"<<endl;
                getch();
            }
            else
            {
                int productnumber;
                SelectedProducts();
                cout << "Enter Product do yo want to delete...";
                cin >> productnumber;
                if(productnumber>selectedCount)
                {
                    cout << "Invalid Input"<<endl;
                    cout << "Press any key to continue" << endl;
                    getch();
                }
                else
                {
                deleteCustomerSelectedProducts(productnumber);
                cout << "Product deleted successfully!"<<endl;
                cout << "Press any key to continue" << endl;
                getch();
                }
            }
        }
        else if(option=="5")
        {
            viewContact();

        }
        else if (option == "6")
        {
            system("cls");
            topHeader();
            cout << "    Selected products." << endl;
            cout << "........................" << endl;
            if(selectedCount==0)
            {
                cout << "No products has been choosen!"<<endl;
                cout << "Press any key to continue"<< endl;
                getch();
            }
            else
            {
                seeSelectedProducts();
                cout << "Press any key to continue";
                getch();
            }
        }
        else if(option=="7")
        {
            break;
        }
        else if(option!="1"||option!="2"||option!="3"||option!="4"||option!="5"||option!="6")
        {
            cout << "Invalid Input"<<endl;
            cout << "Press any key to continue" << endl;
            getch();
        }
    }
}
//List that showed to customer and he has to choose
string customerList()
{
    system("cls");
    topHeader();
    string option;
    cout << "    Customer List." << endl;
    cout << "...................." << endl;
    cout << "1.View the list of products." << endl;
    cout << "2.Choose products." << endl;
    cout << "3.Add Address." << endl;
    cout << "4.Delete from products." << endl;
    cout << "5.See Manager Contact" << endl;
    cout << "6.See selected products." << endl;
    cout << "7.Back." << endl;
    cout << "Choose option...." << endl;
    cin >> option;
    return option;
}
//to store products added by manager
void addproductsbyManager(string product, float productprice)
{
    managerProducts[productcount] = product;
    Productprice[productcount] = productprice;
    productcount++;
}
//Products added by manager stored in file
void productFile()
{
    fstream file;
    file.open("ProductFile.txt", ios::out);
    for(int i = 0; i < productcount;i++)
    {
        file << managerProducts[i] << "," << Productprice[i] << endl;
    }
    file.close();
}
// Products list that will displays to manager
void viewProducts()
{
    for (int n = 0; n < productcount; n++)
    {
        cout << n + 1 << "." << managerProducts[n] << endl << "Rs." << Productprice[n] << endl;
    }
}
//Read products add by manager
void readProductsFromFile()
{
    int x = 0;
    string word;
    string product;
    string price;
    fstream file;
    file.open("ProductFile.txt", ios::in);
    while (!file.eof())
    {
        getline(file, word);
        if (word == "")
        {
            productcount = x;
            break;
        }
        managerProducts[x] = getField(word,0);
        price = getField(word, 1);
        Productprice[x] = stoi(price);
        cout << price  << "\t"<< Productprice[x];
        x++;
    }
    file.close();
}
//Read Commas by which things are stored in file
string getField(string record, int field)
{
    int commaCount = 0;
    string item = "";
    for (int n = 0; n < record.length(); n++)
    {
        if (record[n] == ',')
        {
            commaCount++;
        }
        else if (commaCount == field)
        {
            item = item + record[n];
        }
    }
    return item;
}
//to store price that is updated by the manager
void updatePrice(int productnumber, float price)
{
    Productprice[productnumber-1] = price;
}
// to delete item that are stored in file
void deleteFromProductFile(int productnumber)
{
    for(int n=productnumber-1;n<productcount;n++)
    {
        managerProducts[n]=managerProducts[n+1];
        Productprice[n]=Productprice[n+1];
    }
    productcount--;
}
//To check phone number if it is valid
bool isValidPhoneNumber(string phonenumber)
{
    bool flag = false;
    int count = 0 ;
    for(int n=0;n<11;n++)
    {
        int value = phonenumber[n] - '0';
        if(value>=0 && value <=9)
        {
            count = count+1;
        }   
    }
    if(count == 11)
    {
        flag = true;
    }
    return flag;
}
//Store products added by the customer from list
void chooseProduct()
{
    int productnumber;
    seeProducts();
    cout << "Enter product number..";
    cin >> productnumber;
    if(productnumber>productcount)
    {
        cout << "Invalid option!"<<endl;
        cout << "Press any key to continue";
        getch();
    }
    else
    {
        if(selectedCount>size)
        {
            cout << "No Space Is Available"<<endl;
            cout << "Press any key to continue";
            getch();
        }
        else
        {   
            selectedproduts[selectedCount] = managerProducts[productnumber-1];
            int productPrice = Productprice[productnumber-1];
            selectedprice[selectedCount] = productPrice;
            selectedCount++;
            cout << "Product Choosed Successfully!"<<endl;
            cout << "Press any key to continue";
            getch();
        }
    }
}
//see products added by the manager to view to perform some action
void seeProducts()
{
    for (int n = 0; n < productcount; n++)
    {
        cout << n + 1 << "." << managerProducts[n] << endl
             << Productprice[n] << endl;
    }
}
//to see products select by custmer and Calculate Bill
void seeSelectedProducts()
{
    int option;
    int totalbill = 0;
    for (int n = 0; n < selectedCount; n++)
    {
        cout << n + 1 << "." << selectedproduts[n] << endl << "Rs." << selectedprice[n] << endl;
        totalbill = totalbill + selectedprice[n];
    }
    cout << "Total bill is Rs." << totalbill << endl;
}
//Phone Number added by the manager to contact him
void managerContact(string phonenumber)
{
    PhoneNumber=phonenumber;
}
//View the Phone Number of Manager To Customer
void viewContact()
{
    system("cls");
    topHeader();
    cout << "     Manager Contact" << endl;
    cout << "........................" << endl;
    cout << "Phone number : "<<PhoneNumber <<endl;
    cout << "Press any key to continue";
    getch();
}
//Add address by the User
void customerAddress(string address)
{
    Address=address;
}
//Delete products if user do not want to buy selected items
void deleteCustomerSelectedProducts(int productnumber)
{
    for(int n=productnumber-1;n<selectedCount;n++)
    {
        selectedproduts[n]=selectedproduts[n+1];
        selectedprice[n]=selectedprice[n+1];
    }
    selectedCount--;
}
//Display Product That user selected to buy
void SelectedProducts()
{
    for (int n = 0; n < selectedCount; n++)
    {
        cout << n + 1 << "." << selectedproduts[n] << endl << "Rs." << selectedprice[n] << endl;
    }
}
//Order that is given by customer
void viewOrder()
{
    seeSelectedProducts();
    cout <<"Address : " << Address <<endl;
    cout << "Press any key to continue...";
    getch();
}