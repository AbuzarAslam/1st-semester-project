#include<iostream>
#include<windows.h>
#include<conio.h>
#include<fstream>
using namespace std;
void welcomeScreen();
string menuScreen();
void headerName();
void Header();
void Instructions();
void printPlayer();
void printEnemy1();
void printMaze();
void movePlayerleft();
void movePlayerright();
void movePlayerup();
void movePlayerdown();
void moveEnemy1();
void gotoxy(int x, int y);
void erasePlayer();
char getCharAtxy(short int x, short int y);
void eraseEnemy();
void createBullet();
void moveBullet();
void printBullet(int x, int y);
void removeBullet(int x, int y);
void inactiveBullet(int idx);
void bulletCollison();
// Player Bullet
char bullet=16;
void createEnemyBullet();
void moveEnemyBullet();
void printEnemyBullet(int x, int y);
void removeEnemyBullet(int x, int y);
void inactiveEnemyBullet(int idx);
void bulletCollison2();
void bulletCollison3();
void createEnemy2Bullet();
void moveEnemy2Bullet();
void createEnemy3Bullet();
void moveEnemy3Bullet();
// It will display score and players health
void addScore();
void printScore();
// Enemy2
void printEnemy2();
void eraseEnemy2();
void moveEnemy2();
// Enemy 3
void printEnemy3();
void eraseEnemy3();
void moveEnemy3();
// File Handlifg
void storeAllCoordinates();
void readAllCoordinates();
string getField(string record, int field);
int timer=0;
// Collison With PLayer
void enemy1Collison();
void enemy2Collison();
void enemy3Collison();
void gameOver();
void youWon();
string Directionenemy1 = "Down";
string Directionenemy3 = "Right";
// PLayer
char tale = 60, head = 62, box = 219, space = 221;
char plane1[4][11] = {
    {' ', ' ', ' ', ' ', ' ', ' ', ' ', '-', '-', '-', ' '},
    {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', space, ' ', ' '},
    {'|', tale, '=', '=', '=', box, box, box, box, head, '|'},
    {' ', ' ', ' ', ' ', ' ', ' ', '0', ' ', '0', ' ', ' '},
};
// enemy
char enemy1[4][11] = {
    {' ', ' ', '-', '-', '-', ' ', ' ', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', space, ' ', ' ', ' ', ' ', ' ', ' ', ' '},
    {'|', tale, box, box, box, box, '=', '=', '=', head, '|'},
    {' ', ' ', '0', ' ', '0', ' ', ' ', ' ', ' ', ' ', ' '},
};
// player coordinates
int planeX = 4;
int planeY = 11;
// enemy1 position
int enemyX = 80;
int enemyY = 4;
//enemy2 position
float enemy2X = 40;
float enemy2Y = 15;
//enemy3 position
int enemy3X = 5;
int enemy3Y = 7;
// player bullets
int bulletX[1000];
int bulletY[1000];
bool isbulletActive[1000];
int bulletcount = 0;
// Player Health
int playerHealth =10;
// Enemy Health
int enemy1Health =10;
int enemy2Health =10;
int enemy3Health =10;
int score = 0;
//enemy1 bullets
int enemyBulletX[1000];
int enemyBulletY[1000];
bool isbulletEnemyActive[1000];
int enemyBulletcount = 0;
//enemy2 bullets
int enemy2BulletX[1000];
int enemy2BulletY[1000];
bool isbulletEnemy2Active[1000];
int enemy2Bulletcount = 0;
//enemy3 bullets
int enemy3BulletX[1000];
int enemy3BulletY[1000];
bool isbulletEnemy3Active[1000];
int enemy3Bulletcount = 0;
// Maze
string maze[30][1] = {
    {"                                                                                                               "},
    {" ##############################################################################################################"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" #                                                                                                            #"},
    {" ##############################################################################################################"},
};
main()
{
    system("cls");
    welcomeScreen();
    headerName();
    cout << "Press any key to continue"<<endl;
    getch();
    system("cls");
    string option = "0";
    while(option!="4")
    {
        option=menuScreen();
        if(option == "2")
        {
            Instructions();
            cout << "Press any key to continue...";
            getch();
        }
        else if(option == "3")
        {
            readAllCoordinates();
        }
        else if(option=="1" || option == "3")
        {
            system("cls");
            printMaze();
            printPlayer();
            printEnemy1();
            printEnemy2();
            printEnemy3();
            while (true)
            {
                printScore();
                if (GetAsyncKeyState(VK_LEFT))
                {
                    movePlayerleft();
                }
                if (GetAsyncKeyState(VK_RIGHT))
                {
                    movePlayerright();
                }
                if (GetAsyncKeyState(VK_UP))
                {
                    movePlayerup();
                }
                if (GetAsyncKeyState(VK_DOWN))
                {
                    movePlayerdown();
                }
                Sleep(1);
                if (GetAsyncKeyState(VK_SPACE))
                {
                    createBullet();
                }
                if (GetAsyncKeyState(VK_ESCAPE))
                {
                    storeAllCoordinates();
                    break;
                }
                moveEnemyBullet();
                moveBullet();
                Sleep(100);
                bulletCollison();
                moveEnemy3Bullet();
                moveEnemy2Bullet();
                bulletCollison2();
                bulletCollison3();
                enemy1Collison();
                enemy2Collison();
                enemy3Collison();
                if(enemy1Health <= 0)
                {
                    eraseEnemy();
                    enemyX = 150;
                    enemyY = 6;
                }
                else
                {
                    moveEnemy1();
                    createEnemyBullet();
                }
                if(enemy2Health <= 0)
                {
                    eraseEnemy2();
                    enemy2X = 150;
                    enemy2Y = 6;
                }
                else
                {
                    moveEnemy2();
                    createEnemy2Bullet();
                }
                if(enemy3Health <= 0)
                {
                    eraseEnemy3();
                    enemy3X = 150;
                    enemy3Y = 6;
                }
                else{
                    createEnemy3Bullet();
                    moveEnemy3();
                }
                if(playerHealth<=0)
                {
                    system("cls");
                    gameOver();
                    getch();
                    break;
                }
                if(enemy1Health <= 0 && enemy2Health <= 0 && enemy3Health <= 0)
                {
                    system("cls");
                    youWon();
                    getch();
                    break;
                }
            }
            return 0;
        }
    }
}
//Logo that will display on welcome screen
void welcomeScreen()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=11;
    SetConsoleTextAttribute(hConsole,k); 
    cout << "                                                     " << endl ;
    cout << "                       .....                         " << endl ;
    cout << "                      .--!--.                        " << endl ;
    cout << "     ..           .../       \\                       " << endl ;
    cout << "    /  \\     --------         \\ ----.                " << endl ;
    cout << "   |    \\ --/                       |                " << endl ;
    cout << "   |                                | |              " << endl ;
    cout << "   |   ....                         |.|              " << endl ;
    cout << "   .                  .::::         | |              " << endl ;
    cout << "    \\______________________________ |       .  . . . .   " << endl ;
    cout << "       |                   |                         " << endl ;
    cout << "       0                  0.0                        " << endl ;
    cout << "                                                  " << endl ;
    cout << "                                                  " << endl ;
    cout << "                                                  " << endl ;

}
// Game name that will display on welcome screen
void headerName()
{                                                                                                              
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
int k=2;
SetConsoleTextAttribute(hConsole,k); 
cout << "      _/        _//////// _///////         _////      _///////   _//             _/        _///     _/ /_////////  " << endl;
cout << "     _/ //      _//       _//    _//     _//    _//   _//    _// _//            _/ //      _/ _//   _/ /_//        " << endl;
cout << "    _/  _//     _//       _//    _//   _//        _// _//    _// _//           _/  _//     _// _//  _/ /_//      " << endl;
cout << "   _//   _//    _//////   _/ _//       _//        _// _///////   _//          _//   _//    _//  _// _/ /_//////  " << endl;
cout << "  _////// _//   _//       _//  _//     _//        _// _//        _//         _////// _//   _//   _/ _/ /_//      " << endl;
cout << " _//       _//  _//       _//    _//     _//     _//  _//        _//        _//       _//  _//    _/ / /_//      " << endl;
cout << "_//         _// _//////// _//      _//     _////      _//        _//////// _//         _// _//      _/ /_////////" << endl;
cout << endl<<endl;
cout << "_//////// _//    _////    _//     _// _/// _//////  " << endl;
cout << "_//       _//  _/    _//  _//     _//      _//    " << endl;
cout << "_//       _// _//         _//     _//      _//    " << endl;
cout << "_//////   _// _//         _////// _//      _//    " << endl;
cout << "_//       _// _//   _//// _//     _//      _//    " << endl;
cout << "_//       _//  _//    _/  _//     _//      _//    " << endl;
cout << "_//       _//   _/////    _//     _//      _//   " << endl;
}
// Header name that will display on top of menus
void Header()
{
    system("cls");
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=9;
    SetConsoleTextAttribute(hConsole,k); 
    cout << "      _/        _//////// _///////         _////      _///////   _//             _/        _///     _/ /_////////  " << endl;
    cout << "     _/ //      _//       _//    _//     _//    _//   _//    _// _//            _/ //      _/ _//   _/ /_//        " << endl;
    cout << "    _/  _//     _//       _//    _//   _//        _// _//    _// _//           _/  _//     _// _//  _/ /_//      " << endl;
    cout << "   _//   _//    _//////   _/ _//       _//        _// _///////   _//          _//   _//    _//  _// _/ /_//////  " << endl;
    cout << "  _////// _//   _//       _//  _//     _//        _// _//        _//         _////// _//   _//   _/ _/ /_//      " << endl;
    cout << " _//       _//  _//       _//    _//     _//     _//  _//        _//        _//       _//  _//    _/ / /_//      " << endl;
    cout << "_//         _// _//////// _//      _//     _////      _//        _//////// _//         _// _//      _/ /_////////" << endl;
    cout << endl<<endl;
    cout << "_//////// _//    _////    _//     _// _/// _//////  " << endl;
    cout << "_//       _//  _/    _//  _//     _//      _//    " << endl;
    cout << "_//       _// _//         _//     _//      _//    " << endl;
    cout << "_//////   _// _//         _////// _//      _//    " << endl;
    cout << "_//       _// _//   _//// _//     _//      _//    " << endl;
    cout << "_//       _//  _//    _/  _//     _//      _//    " << endl;
    cout << "_//       _//   _/////    _//     _//      _//   " << endl;
}
// Menu that will display after Welcome screen
string menuScreen()
{
    system("cls");
    Header();
    string option;
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=14;
    SetConsoleTextAttribute(hConsole,k); 
    cout << "   Menu Screen"<<endl;
    cout << ".................."<<endl;
    cout << "1.Start"<<endl;
    cout << "2.Keys"<<endl;
    cout << "3.Resume"<<endl;
    cout << "4.Exit"<<endl;
    cout << "Choose Option...";
    getline(cin,option);
    return option;
}

void Instructions()
{
    system("cls");
    Header();
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=10;
    SetConsoleTextAttribute(hConsole,k); 
    cout << "     Keys"<<endl;
    cout << ".................."<<endl;
    cout << "1.Up                  To move up"<<endl;
    cout << "2.Down                To move down"<<endl;
    cout << "3.Left                To move left"<<endl;
    cout << "4.Right               To move right"<<endl;    
    cout << "5.Esc                 To stop the game"<<endl; 
    cout << "6.Space               To Fire"<<endl; 
}
void gotoxy(int x, int y)
{
    COORD coordinates;
    coordinates.X = x;
    coordinates.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}
// The main player Thunderbolt
void printPlayer()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=5;
    SetConsoleTextAttribute(hConsole,k);
    for (int n = 0; n < 4; n++)
    {
        gotoxy(planeX, planeY + n);
        for (int m = 0; m < 11; m++)
        {
            cout << plane1[n][m];
        }
    }
}

void printEnemy1()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=12;
    SetConsoleTextAttribute(hConsole,k);
    for (int i = 0; i < 4; i++)
    {
        gotoxy(enemyX, enemyY + i);
        for (int j = 0; j < 11; j++)
        {
            cout << enemy1[i][j];
        }
    }
}
// Function that will print maze
void printMaze()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=2;
    SetConsoleTextAttribute(hConsole,k);
    for (int a = 0; a < 30; a++)
    {
        cout << maze[a][0] << endl;
    }
}
// function to move player Thunderbolt left
void movePlayerleft()
{
    char next = getCharAtxy(planeX - 1, planeY);
    if (next == ' ')
    {
        gotoxy(planeX, planeY);
        erasePlayer();
        planeX = planeX - 1;
        gotoxy(planeX, planeY);
        printPlayer();
    }
}
// function to move player Thunderbolt right
void movePlayerright()
{
    char next = getCharAtxy(planeX + 11, planeY);
    if (next == ' ')
    {
        gotoxy(planeX, planeY);
        erasePlayer();
        planeX = planeX + 1;
        gotoxy(planeX, planeY);
        printPlayer();
    }
}
// function to move player Thunderbolt Up
void movePlayerup()
{
    char next = getCharAtxy(planeX, planeY - 1);
    if (next == ' ')
    {
        gotoxy(planeX, planeY);
        erasePlayer();
        planeY = planeY - 1;
        gotoxy(planeX, planeY);
        printPlayer();
    }
}
// function to move player Thunderbolt down
void movePlayerdown()
{
    char next = getCharAtxy(planeX, planeY + 4);
    if (next == ' ')
    {
        gotoxy(planeX, planeY);
        erasePlayer();
        planeY = planeY + 1;
        gotoxy(planeX, planeY);
        printPlayer();
    }
}
// Function that will move enemy Shadowshark UP and DOWN
void moveEnemy1()
{
    if (Directionenemy1 == "Up")
    {
        char next = getCharAtxy(enemyX, enemyY - 1);
        if (next == ' ')
        {
            eraseEnemy();
            enemyY--;
            printEnemy1();
        }
        if (next == '#')
        {
            Directionenemy1 = "Down";
        }
    }
    if (Directionenemy1 == "Down")
    {
        char next = getCharAtxy(enemyX, enemyY + 4);
        if (next == ' ')
        {
            eraseEnemy();
            enemyY++;
            printEnemy1();
        }
        if (next == '#')
        {
            Directionenemy1 = "Up";
        }
    }
}
// Function that will erase Player Thunderbolt from current location
void erasePlayer()
{
    gotoxy(planeX, planeY);
    for (int index = 0; index < 10; index++)
    {
        cout << " ";
    }
    gotoxy(planeX, planeY + 1);
    for (int index = 0; index < 9; index++)
    {
        cout << " ";
    }
    gotoxy(planeX, planeY + 2);
    for (int index = 0; index < 11; index++)
    {
        cout << " ";
    }
    gotoxy(planeX, planeY + 3);
    for (int index = 0; index < 9; index++)
    {
        cout << " ";
    }
}
// Function that will erase enemy1 shadowshark from current location
void eraseEnemy()
{
    gotoxy(enemyX, enemyY);
    cout << "           ";
    gotoxy(enemyX, enemyY + 1);
    cout << "           ";
    gotoxy(enemyX, enemyY + 2);
    cout << "           ";
    gotoxy(enemyX, enemyY + 3);
    cout << "           ";
}
char getCharAtxy(short int x, short int y)
{
    CHAR_INFO ci;
    COORD xy = {0, 0};
    SMALL_RECT rect = {x, y, x, y};
    COORD coorsBufSize;
    coorsBufSize.X = x;
    coorsBufSize.Y = y;
    return ReadConsoleOutput(GetStdHandle(STD_OUTPUT_HANDLE), &ci, coorsBufSize, xy, &rect) ? ci.Char.AsciiChar : ' ';
}
// Function that will create bullets of player Thunderbolt
void createBullet()
{
    bulletX[bulletcount] = planeX + 11;
    bulletY[bulletcount] = planeY;
    isbulletActive[bulletcount] = true;
    gotoxy(planeX + 11, planeY);
    cout << bullet;
    bulletcount++;
}
// Function that will print bullets of player Thunderbolt
void printBullet(int x, int y)
{

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=4;
    SetConsoleTextAttribute(hConsole,k);
    gotoxy(x, y);
    cout << bullet;
}
// Function that will remove bullets of player Thunderbolt
void removeBullet(int x, int y)
{
    gotoxy(x, y);
    cout << ' ';
}
// Function that will stop the bullets
void inactiveBullet(int idx)
{
    isbulletActive[idx] = false;
}
// Function that will move bullet of player
void moveBullet()
{
    for (int n = 0; n < bulletcount; n++)
    {
        if (isbulletActive[n] = true)
        {
            char next = getCharAtxy(bulletX[n] + 1, bulletY[n]);
            if (next != ' ')
            {
                removeBullet(bulletX[n], bulletY[n]);
                inactiveBullet(n);
            }
            else
            {
                removeBullet(bulletX[n], bulletY[n]);
                bulletX[n] = bulletX[n] + 1;
                printBullet(bulletX[n], bulletY[n]);
            }
        }
    }
}
// Function that will detect the player Thunderbolt bulllet with enemy1 Shadowshark
void bulletCollison()
{
    for (int n = 0; n < bulletcount; n++)
    {
        if (isbulletActive[n] == true)
        {
            if (bulletX[n] + 1 == enemyX && (bulletY[n] == enemyY || bulletY[n] == enemyY + 2 || bulletY[n] == enemyY + 3))
            {
                addScore();
                enemy1Health--;
            }
            if (enemyX - 1 == bulletX[n] && enemyY + 1 == bulletY[n])
            {
                addScore();
                enemy1Health--;
            }
        }
    }
}
// Function that will detect the PLayer Thunderbolt Collison with enemy2 Yellowbarron
void bulletCollison2()
{
    for (int n = 0; n < bulletcount; n++)
    {
        if (isbulletActive[n] == true)
        {
            if (bulletX[n] + 1 == enemy2X && (bulletY[n] == enemy2Y || bulletY[n] == enemy2Y + 2 || bulletY[n] == enemy2Y + 3))
            {
                addScore();
                enemy2Health--;
            }
            if (enemy2X - 1 == bulletX[n] && enemy2Y + 1 == bulletY[n])
            {
                addScore();
                enemy2Health--;
            }
        }
    }
}
// Function that will detect the PLayer Thunderbolt Collison with enemy2 Bluebarron
void bulletCollison3()
{
    for (int n = 0; n < bulletcount; n++)
    {
        if (isbulletActive[n] == true)
        {
            if (bulletX[n] + 1 == enemy3X && (bulletY[n] == enemy3Y || bulletY[n] == enemy3Y + 2 || bulletY[n] == enemy3Y + 3))
            {
                addScore();
                enemy3Health--;
            }
            if (enemy3X - 1 == bulletX[n] && enemy3Y + 1 == bulletY[n])
            {
                addScore();
                enemy3Health--;
            }
        }
    }
}
// Function that will add in score
void addScore()
{
    score++;
}
// Function that will print score
void printScore()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=11;
    SetConsoleTextAttribute(hConsole,k); 
    gotoxy(115, 10);
    cout << "Score: " << score;
    gotoxy(115, 11);
    cout << "Health PLayer " << playerHealth << "    ";
    gotoxy(115, 12);
    cout << "Health Enemy1: " << enemy1Health << "    ";
    gotoxy(115, 13);
    cout << "Health Enemy2: " << enemy2Health << "    ";
    gotoxy(115, 14);
    cout << "Health Enemy3: " << enemy3Health<< "    ";
}
// Function that will print enemy2
void printEnemy2()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=6;
    SetConsoleTextAttribute(hConsole,k);
    for (int i = 0; i < 4; i++)
    {
        gotoxy(enemy2X, enemy2Y + i);
        for (int j = 0; j < 11; j++)
        {
            cout << enemy1[i][j];
        }
    }
}
// Function that will erase enemy2 Yellowbarron
void eraseEnemy2()
{
    gotoxy(enemy2X, enemy2Y);
    cout << "           ";
    gotoxy(enemy2X, enemy2Y + 1);
    cout << "           ";
    gotoxy(enemy2X, enemy2Y + 2);
    cout << "           ";
    gotoxy(enemy2X, enemy2Y + 3);
    cout << "           ";
}
// Function that will move(Chasing) enemy2 Yellowbarron
void moveEnemy2()
{
    if(enemy2X==planeX && enemy2Y == planeY)
    {
        enemy2X = 40;
        enemy2Y = 15;
    }
    if (enemy2X > planeX)
    {
        char next = getCharAtxy(enemy2X - 1, enemy2Y);
        if (next == ' ')
        {
            eraseEnemy2();
            enemy2X = enemy2X - 0.5;
            printEnemy2();
        }
    }
    if (enemy2X < planeX)
    {
        char next = getCharAtxy(enemy2X + 11, enemy2Y);
        if (next == ' ')
        {
            eraseEnemy2();
            enemy2X = enemy2X + 0.5;
            printEnemy2();
        }
    }
    if (enemy2Y > planeY)
    {
        char next = getCharAtxy(enemy2X, enemy2Y - 1);
        if (next == ' ')
        {
            eraseEnemy2();
            enemy2Y = enemy2Y - 0.5;
            printEnemy2();
        }
    }
    if (enemy2Y < planeY)
    {
        char next = getCharAtxy(enemy2X, enemy2Y + 4);
        if (next == ' ')
        {
            eraseEnemy2();
            enemy2Y = enemy2Y + 0.5;
            printEnemy2();
        }
    }
}
// Function that will create enemy1 Shadowshark bullet
void createEnemyBullet()
{
    timer++;
    if(timer%5==0)
        {
            enemyBulletX[enemyBulletcount] = enemyX - 1;
            enemyBulletY[enemyBulletcount] = enemyY;
            isbulletEnemyActive[enemyBulletcount] = true;
            gotoxy(enemyX - 1, enemyY);
            cout << "-";
            enemyBulletcount++;
        }
}
// Function that will create enemy2 Yellowbarron bullet
void createEnemy2Bullet()
{
    if(timer%5==0)
        {
            enemy2BulletX[enemy2Bulletcount] = enemy2X - 3;
            enemy2BulletY[enemy2Bulletcount] = enemy2Y+3;
            isbulletEnemy2Active[enemy2Bulletcount] = true;
            gotoxy(enemy2X - 3, enemy2Y+3);
            cout << "*";
            enemy2Bulletcount++;
        }
}
// Function that will create enemy Bluebarron bullet
void createEnemy3Bullet()
{
    if(timer%5==0)
        {
            enemy3BulletX[enemy3Bulletcount] = enemy3X - 3;
            enemy3BulletY[enemy3Bulletcount] = enemy3Y+3;
            isbulletEnemy3Active[enemy3Bulletcount] = true;
            gotoxy(enemy3X - 3, enemy3Y+3);
            cout << "*";
            enemy3Bulletcount++;
        }
}
// Function that will move enemy2 Yellowbarron bullet
void moveEnemy2Bullet()
{
    for (int n = 0; n < enemy2Bulletcount; n++)
    {
        if (isbulletEnemy2Active[n] = true)
        {
            char next = getCharAtxy(enemy2BulletX[n] - 1, enemy2BulletY[n]);
            if (next != ' ')
            {
                removeEnemyBullet(enemy2BulletX[n], enemy2BulletY[n]);
                isbulletEnemy2Active[n] = false;
            }
            else
            {
                removeEnemyBullet(enemy2BulletX[n], enemy2BulletY[n]);
                enemy2BulletX[n] = enemy2BulletX[n] - 1;
                gotoxy(enemy2BulletX[n], enemy2BulletY[n]);
                cout << ",";
            }
        }
    }
}
// Function that will move enemy3 Bluebarron bullet
void moveEnemy3Bullet()
{
    for (int n = 0; n < enemy3Bulletcount; n++)
    {
        if (isbulletEnemy3Active[n] = true)
        {
            char next = getCharAtxy(enemy3BulletX[n] - 1, enemy3BulletY[n]);
            if (next != ' ')
            {
                removeEnemyBullet(enemy3BulletX[n], enemy3BulletY[n]);
                isbulletEnemy3Active[n] = false;
            }
            else
            {
                removeEnemyBullet(enemy3BulletX[n], enemy3BulletY[n]);
                enemy3BulletX[n] = enemy3BulletX[n] - 1;
                gotoxy(enemy3BulletX[n], enemy3BulletY[n]);
                cout << "*";
            }
        }
    }
}
// Function that will print enemy1 Shadowshark bullet
void printEnemyBullet(int x, int y)
{
    gotoxy(x, y);
    cout << '-';
}
// Function that will remove enemy1 Shadowshark bullet
void removeEnemyBullet(int x, int y)
{
    gotoxy(x, y);
    cout << ' ';
}
// Function that will stop enemy1 Shadowshark bullet
void inactiveEnemyBullet(int idx)
{
    isbulletEnemyActive[idx] = false;
}
// Function that will move enemy1 Shadowshark bullet
void moveEnemyBullet()
{
    for (int n = 0; n < enemyBulletcount; n++)
    {
        if (isbulletEnemyActive[n] = true)
        {
            char next = getCharAtxy(enemyBulletX[n] - 1, enemyBulletY[n]);
            if (next != ' ')
            {
                removeEnemyBullet(enemyBulletX[n], enemyBulletY[n]);
                inactiveEnemyBullet(n);
            }
            else
            {
                removeEnemyBullet(enemyBulletX[n], enemyBulletY[n]);
                enemyBulletX[n] = enemyBulletX[n] - 1;
                printEnemyBullet(enemyBulletX[n], enemyBulletY[n]);
            }
        }
    }
}
// Function that will print enemy3 Bluebarron
void printEnemy3()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int k=1;
    SetConsoleTextAttribute(hConsole,k);
    for (int i = 0; i < 4; i++)
    {
        gotoxy(enemy3X, enemy3Y + i);
        for (int j = 0; j < 11; j++)
        {
            cout << enemy1[i][j];
        }
    }
}
// Function that will erase enemy3 Bluebarron
void eraseEnemy3()
{
    gotoxy(enemy3X, enemy3Y);
    cout << "           ";
    gotoxy(enemy3X, enemy3Y + 1);
    cout << "           ";
    gotoxy(enemy3X, enemy3Y + 2);
    cout << "           ";
    gotoxy(enemy3X, enemy3Y + 3);
    cout << "           ";
}
// Function that will move enemy3 Bluebarron left to right
void moveEnemy3()
{
    if (Directionenemy3 == "Right")
    {
        char next = getCharAtxy(enemy3X + 11, enemy3Y);
        if (next == ' ')
        {
            eraseEnemy3();
            enemy3X++;
            printEnemy3();
        }
        if (enemy3X>=70)
        {
            Directionenemy3 = "Left";
        }
    }
    if (Directionenemy3 == "Left")
    {
        char next = getCharAtxy(enemyX - 1, enemyY);
        if (next == ' ')
        {
            eraseEnemy3();
            enemy3X--;
            printEnemy3();
        }
        if (enemy3X<=25)
        {
            Directionenemy3 = "Right";
        }
    }
}
// Collison of enemy1 shadowshark bullet with player Thunderbolt
void enemy1Collison()
{
    for (int n = 0; n < enemyBulletcount; n++)
    {
        if (isbulletEnemyActive[n] == true)
        {
            if (enemyBulletX[n] - 1 == planeX && (enemyBulletY[n] == planeY || enemyBulletY[n] == planeY + 2 || enemyBulletY[n] == planeY + 3))
            {
                playerHealth--;
            }
            if (planeX - 1 == enemyBulletX[n] && planeY + 1 == enemyBulletY[n])
            {
                playerHealth--;
            }
        }
    }
}
// Collison of enemy Yellowbarron bullet with player Thunderbolt
void enemy2Collison()
{
    for (int n = 0; n < enemy2Bulletcount; n++)
    {
        if (isbulletEnemyActive[n] == true)
        {
            if (enemy2BulletX[n] - 1 == planeX && (enemy2BulletY[n] == planeY || enemy2BulletY[n] == planeY + 2 || enemy2BulletY[n] == planeY + 3))
            {
                playerHealth--;
            }
            if (planeX - 1 == enemy2BulletX[n] && planeY + 1 == enemy2BulletY[n])
            {
                playerHealth--;
            }
        }
    }
}
// Collison of enemy2 Yellowbarron bullet with player Thunderbolt
void enemy3Collison()
{
    for (int n = 0; n < enemy3Bulletcount; n++)
    {
        if (isbulletEnemyActive[n] == true)
        {
            if (enemy3BulletX[n] - 1 == planeX && (enemy3BulletY[n] == planeY || enemy3BulletY[n] == planeY + 2 || enemy3BulletY[n] == planeY + 3))
            {
                playerHealth--;
            }
            if (planeX - 1 == enemy3BulletX[n] && planeY + 1 == enemy3BulletY[n])
            {
                playerHealth--;
            }
        }
    }
}
// Logo that will display when game will over
void gameOver()
{                                                                                                              
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
int k=5;
SetConsoleTextAttribute(hConsole,k); 
cout << " ::::::::      :::     ::::    ::::  ::::::::::   ::::::::  :::     ::: :::::::::: :::::::::  " << endl;
cout << ":+:    :+:   :+: :+:   +:+:+: :+:+:+ :+:         :+:    :+: :+:     :+: :+:        :+:    :+: " << endl;
cout << "+:+         +:+   +:+  +:+ +:+:+ +:+ +:+         +:+    +:+ +:+     +:+ +:+        +:+    +:+ " << endl;
cout << ":#:        +#++:++#++: +#+  +:+  +#+ +#++:++#    +#+    +:+ +#+     +:+ +#++:++#   +#++:++#:  " << endl;
cout << "+#+   +#+# +#+     +#+ +#+       +#+ +#+         +#+    +#+  +#+   +#+  +#+        +#+    +#+ " << endl;
cout << "#+#    #+# #+#     #+# #+#       #+# #+#         #+#    #+#   #+#+#+#   #+#        #+#    #+# " << endl;
cout << " ########  ###     ### ###       ### ##########   ########      ###     ########## ###    ###" << endl<<endl;
cout <<"Score = "<< score;
}
// Logo that will display when game will won
void youWon()
{                                                                                                              
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
int k=5;
SetConsoleTextAttribute(hConsole,k); 
cout << ":::   :::  ::::::::  :::    :::    :::       :::  ::::::::  ::::    :::  " << endl;
cout << ":+:   :+: :+:    :+: :+:    :+:    :+:       :+: :+:    :+: :+:+:   :+:  " << endl;
cout << " +:+ +:+  +:+    +:+ +:+    +:+    +:+       +:+ +:+    +:+ :+:+:+  +:+  " << endl;
cout << "  +#++:   +#+    +:+ +#+    +:+    +#+  +:+  +#+ +#+    +:+ +#+ +:+ +#+  " << endl;
cout << "   +#+    +#+    +#+ +#+    +#+    +#+ +#+#+ +#+ +#+    +#+ +#+  +#+#+#  " << endl;
cout << "   #+#    #+#    #+# #+#    #+#     #+#+# #+#+#  #+#    #+# #+#   #+#+#  " << endl;
cout << "   ###     ########   ########       ###   ###    ########  ###    ####  " << endl<< endl;
cout <<"Score = "<< score;
}
// File Handing Functions
//  Storing Functions
void storeAllCoordinates()
{
  fstream files;
    files.open("Coordinates.txt",ios::out);
      files << planeX <<"," << planeY << endl; 
      files << enemyX <<"," << enemyY << endl;
      files << enemy2X <<"," << enemy2Y << endl; 
      files << enemy3X <<"," << enemy3Y << endl;
      files << playerHealth <<"," << enemy1Health <<","<< enemy2Health <<","<< enemy3Health << endl;  
      files << score << endl;
    files.close();
}
// Reading Functions
void readAllCoordinates()
{
    int lines = 1;
    fstream files;
    files.open("Coordinates.txt",ios::in);
    while(!files.eof())
    {
        string line;
        getline(files,line);
        if (line == "") break;
        if(lines==1)
        {
            planeX = stoi(getField(line,1));
            planeY = stoi(getField(line,2));
        }
        if(lines==2)
        {
            enemyX = stoi(getField(line,1));
            enemyY = stoi(getField(line,2));
        }
        if(lines==3)
        {
            enemy2X = stoi(getField(line,1));
            enemy2Y = stoi(getField(line,2));
        }
        if(lines==4)
        {
            enemy3X = stoi(getField(line,1));
            enemy3Y = stoi(getField(line,2));
        }
        if(lines==5)
        {
            playerHealth = stoi(getField(line,1));
            enemy1Health = stoi(getField(line,2));
            enemy2Health = stoi(getField(line,3));
            enemy3Health = stoi(getField(line,4));
        }
        if(lines==6)
        {
            score = stoi(line);
        }
        lines++;
        
    }
}
string getField(string record, int field)
{
    int commaCount = 1;
    string item = "";
    for (int x = 0; x < record.length(); x++)
    {
        if (record[x] == ',')
        {
            commaCount = commaCount + 1;
        }
        else if (commaCount == field)
        {
            item = item + record[x];
        }
    }
    return item;
}